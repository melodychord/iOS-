//
//  RecommendHeadView.h
//  DouYU
//
//  Created by Alesary on 15/11/2.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecommendHeadView : UIView

@property (strong, nonatomic) IBOutlet UILabel *more;

@property (strong, nonatomic) IBOutlet UIImageView *moreimage;

@property (strong, nonatomic) IBOutlet UILabel *Title;
@end
