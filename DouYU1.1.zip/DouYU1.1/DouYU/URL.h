
//
//  URL.h
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#ifndef URL_h
#define URL_h


#define TOP_URl @"http://www.douyutv.com/api/v1/slide/6"

#define NEW_URl @"http://www.douyutv.com/api/v1/home_newbie_list?aid=ios&auth=3c0837ba99e8506db591b7971dfb20c2&client_sys=ios&time="

#define NEW_Image_URl @"http://uc.douyutv.com/upload/avatar"

#define NEW_Time_URl @"_avatar_big.jpg?upt="

#define CHANEL_URl @"http://www.douyutv.com/api/v1/channel?aid=ios&auth=6a4c6b01d851ceece76aee1980b9e5bb&client_sys=ios&limit=4&time="



#endif /* URL_h */
