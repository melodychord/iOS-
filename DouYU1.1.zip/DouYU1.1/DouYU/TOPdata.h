//
//  TOPdata.h
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TOPdata : NSObject

@property(nonatomic,strong)NSString *Id;

@property(nonatomic,strong)NSString *title;

@property(nonatomic,strong)NSString *pic_url;

@property(nonatomic,strong)NSString *hls_url;

@property(nonatomic,strong)NSDictionary *room;


@end
