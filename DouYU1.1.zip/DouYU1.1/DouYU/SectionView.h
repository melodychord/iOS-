//
//  SectionView.h
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionView : UIView

@property (strong, nonatomic) IBOutlet UIButton *DownButton;
@property (strong, nonatomic) IBOutlet UILabel *Title;

@end
