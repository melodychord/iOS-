//
//  SectionView.m
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import "SectionView.h"

@implementation SectionView

-(id)init
{
    self=[[[NSBundle mainBundle]loadNibNamed:@"SectionView" owner:nil options:nil] firstObject];
    
    if (self) {
        
    }
    
    return self;
}

@end
