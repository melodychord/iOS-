//
//  BaseViewController.h
//  DouYU
//
//  Created by Alesary on 15/10/29.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Public.h"

@interface BaseViewController : UIViewController


@end
