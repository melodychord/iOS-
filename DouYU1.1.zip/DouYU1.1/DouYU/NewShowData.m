//
//  NewShowData.m
//  DouYU
//
//  Created by Alesary on 15/11/6.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import "NewShowData.h"

@implementation NewShowData


//-(id)initWithDictionary:(NSDictionary *)dictionary
//{
//    if (self=[super init]) {
//        
//        self.nickname=dictionary[@"nickname"];
//        self.game_name=dictionary[@"game_name"];
//        self.game_url=dictionary[@"game_url"];
//        
//        self.owner_uid=dictionary[@"owner_uid"];
//        self.url=dictionary[@"url"];
//        self.vod_quality=dictionary[@"vod_quality"];
//        
//        self.specific_status=dictionary[@"specific_status"];
//        self.specific_catalog=dictionary[@"specific_catalog"];
//        self.show_status=dictionary[@"show_status"];
//        
//        self.show_time=dictionary[@"show_time"];
//        self.room_name=dictionary[@"room_name"];
//        self.cate_id=dictionary[@"cate_id"];
//        
//        self.nickname=dictionary[@"nickname"];
//        self.game_name=dictionary[@"game_name"];
//        self.game_url=dictionary[@"game_url"];
//        
//        self.room_src=dictionary[@"room_src"];
//        self.room_id=dictionary[@"room_id"];
//
//    }
//    
//    return self;
//}

@end
