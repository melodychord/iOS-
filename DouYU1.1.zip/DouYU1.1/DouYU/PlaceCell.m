//
//  PlaceCell.m
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import "PlaceCell.h"

@implementation PlaceCell



@end
