//
//  MoreViewController.h
//  DouYU
//
//  Created by Alesary on 15/11/3.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import "BaseViewController.h"

@interface MoreViewController : BaseViewController

@property(nonatomic,strong)NSString *Cate_id;
@end
