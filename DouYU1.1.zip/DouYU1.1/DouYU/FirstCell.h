//
//  FirstCell.h
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstCell : UITableViewCell

+(instancetype)GetCellWithTableView:(UITableView *)tableView;

@end
