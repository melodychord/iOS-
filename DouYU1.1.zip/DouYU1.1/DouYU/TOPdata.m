//
//  TOPdata.m
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import "TOPdata.h"

@implementation TOPdata

//-(id)initWithDictionary:(NSDictionary *)dictionary
//{
//    if (self=[super init]) {
//        
//        self.Id=dictionary[@"id"];
//        self.title=dictionary[@"pic_url"];
//        self.pic_url=dictionary[@"pic_url"];
//        self.hls_url=dictionary[@"hls_url"];
//        self.room=dictionary[@"room"];
//    }
//    
//    return self;
//}

@end
