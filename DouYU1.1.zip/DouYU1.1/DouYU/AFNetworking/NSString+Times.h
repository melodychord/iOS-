//
//  NSString+Times.h
//  DouYU
//
//  Created by Alesary on 15/11/5.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Times)

+(NSString *)GetNowTimes;

@end
