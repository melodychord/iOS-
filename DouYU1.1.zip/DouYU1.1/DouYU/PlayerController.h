//
//  PlayerController.h
//  DouYU
//
//  Created by admin on 15/11/8.
//  Copyright © 2015年 Alesary. All rights reserved.
//

#import "BaseViewController.h"

@interface PlayerController : BaseViewController

@property(nonatomic,strong)NSString *Hls_url;

@end
